package recommender;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RecomendadorActividadesTest {

    private final RecomendadorActividades recomendador = new RecomendadorActividades();

    @Test
    void testSaludBloqueaActividades() {
        EstadoSalud noSano = new EstadoSalud(false, true);
        Clima clima = new Clima(20, 50, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("No se recomienda realizar ninguna actividad.",
                recomendador.recomendar(clima, noSano, espacio));
    }

    @Test
    void testQuedarseEnCasaBajoCeroConLluvia() {
        Clima clima = new Clima(-5, 10, true);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("Quédese en casa.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testEsquiBajoCeroSinLluviaConCapacidad() {
        Clima clima = new Clima(-2, 10, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 5);

        assertEquals("Actividades de esquí.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testNoEsquiSinCapacidad() {
        Clima clima = new Clima(-2, 10, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 10);

        assertEquals("Aforo completo, no se puede realizar esquí.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testSenderismoConClimaFresco() {
        Clima clima = new Clima(10, 40, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(5, 1);

        assertEquals("Senderismo o escalada.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testPlayaOPiscinaConCalor() {
        Clima clima = new Clima(32, 30, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(100, 50);

        assertEquals("Ir a la playa o piscina.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testPiscinaSinAforo() {
        Clima clima = new Clima(32, 30, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(100, 100);

        assertEquals("La piscina está en aforo completo.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testCatalogoPrimavera() {
        Clima clima = new Clima(20, 50, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("Actividades de catálogo primavera/verano/otoño.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testCulturalOGastronomico() {
        Clima clima = new Clima(28, 55, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("Actividades culturales o gastronómicas.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testFallbackSinRecomendacion() {
        Clima clima = new Clima(15, 80, true);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("No hay recomendación disponible.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testHumedadAltaBloqueaCatalogo() {
        Clima clima = new Clima(20, 70, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("No hay recomendación disponible.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testLluviaDesactivaExterior() {
        Clima clima = new Clima(10, 40, true);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("No hay recomendación disponible.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testBajoCeroConAltaHumedad() {
        Clima clima = new Clima(-5, 50, false);
        EstadoSalud estado = new EstadoSalud(true, false);
        Espacio espacio = new Espacio(10, 0);

        assertEquals("No hay recomendación disponible.",
                recomendador.recomendar(clima, estado, espacio));
    }

    @Test
    void testArgumentosNulos() {
        assertThrows(IllegalArgumentException.class,
                () -> recomendador.recomendar(null, null, null));
    }
}
