package recommender;

public class Clima {

    private int temperatura;
    private int humedad;
    private boolean precipitacion;

    public Clima(int temperatura, int humedad, boolean precipitacion) {
        this.temperatura = temperatura;
        this.humedad = humedad;
        this.precipitacion = precipitacion;
    }

    public int getTemperatura() {
        return temperatura;
    }

    public int getHumedad() {
        return humedad;
    }

    public boolean hayPrecipitacion() {
        return precipitacion;
    }
}
