package recommender;

public class RecomendadorActividades {

    public String recomendar(Clima clima, EstadoSalud estado, Espacio espacio) {

        if (clima == null || estado == null || espacio == null) {
            throw new IllegalArgumentException("Los parámetros no pueden ser nulos");
        }
        
        if (!estado.isSano() || estado.isRiesgo()) {
            return "No se recomienda realizar ninguna actividad.";
        }

        int temperatura = clima.getTemperatura();
        int humedad = clima.getHumedad();
        boolean lluvia = clima.hayPrecipitacion();

        if (temperatura < 0) {
            if (lluvia) {
                return "Quédese en casa.";
            }
            if (humedad < 15 && espacio.plazasDisponibles() > 0) {
                return "Actividades de esquí.";
            }
            if (espacio.plazasDisponibles() <= 0) {
                return "Aforo completo, no se puede realizar esquí.";
            }
            return "No hay recomendación disponible.";
        }

        if (temperatura <= 15 && !lluvia) {
            return "Senderismo o escalada.";
        }

        if (temperatura >= 30) {
            if (espacio.plazasDisponibles() > 0) {
                return "Ir a la playa o piscina.";
            }
            return "La piscina está en aforo completo.";
        }

        if (!lluvia && humedad <= 60 && temperatura > 25) {
            return "Actividades culturales o gastronómicas.";
        }

        if (!lluvia && humedad <= 60) {
            return "Actividades de catálogo primavera/verano/otoño.";
        }


        return "No hay recomendación disponible.";
    }
}
