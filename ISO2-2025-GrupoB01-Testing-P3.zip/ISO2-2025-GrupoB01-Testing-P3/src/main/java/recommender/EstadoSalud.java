package recommender;

public class EstadoSalud {

    private boolean sano;
    private boolean riesgo;

    public EstadoSalud(boolean sano, boolean riesgo) {
        this.sano = sano;
        this.riesgo = riesgo;
    }

    public boolean isSano() {
        return sano;
    }

    public boolean isRiesgo() {
        return riesgo;
    }
}
