package recommender;

public class Espacio {

    private int capacidad;
    private int ocupacion;

    public Espacio(int capacidad, int ocupacion) {
        this.capacidad = capacidad;
        this.ocupacion = ocupacion;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public int getOcupacion() {
        return ocupacion;
    }

    public int plazasDisponibles() {
        return capacidad - ocupacion;
    }
}
